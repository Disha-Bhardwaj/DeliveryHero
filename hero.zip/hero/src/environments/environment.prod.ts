export const environment = {
  clientId:
    "494602742629-jivk9d4jdgf95rg9v8k58pmuofkkbib2.apps.googleusercontent.com",
  production: true,
  name: "live",
  URL: 'https://emio.eclerx.com/api/',
};
